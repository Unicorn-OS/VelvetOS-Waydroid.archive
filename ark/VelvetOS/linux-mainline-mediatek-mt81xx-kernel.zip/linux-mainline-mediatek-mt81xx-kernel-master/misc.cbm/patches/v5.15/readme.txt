one patch did not apply properly anymore for 5.15.37 as it was already in: drivers/gpu/drm/mediatek/mtk_dsi.c
